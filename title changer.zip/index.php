
<?php // Silence is golden
